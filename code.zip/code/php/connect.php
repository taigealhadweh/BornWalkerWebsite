<?php
    # mysql db constants DB_HOST, DB_USER, DB_PASS, DB_NAME
    const DB_HOST = '40.126.240.245';
    const DB_USER = 'k10838a';
    const DB_PASS = 'password';
    const DB_NAME = 'bornWalkerMap';

mysqli_connect('40.126.240.245', 'k10838a', 'password','bornWalkerMap');

//mysqli_select_db('bornWalkerMap');
?>