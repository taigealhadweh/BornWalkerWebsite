function clearMarkers() {
        setMapOnAll(null);
      }